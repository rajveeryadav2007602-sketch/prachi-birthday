PRACHI — FINAL CINEMATIC BIRTHDAY SURPRISE

1. Extract the ZIP completely.
2. Open index.html in Chrome.
3. Click “Open your surprise”. A celebratory fireworks/confetti-style reveal appears, then the page smoothly slides to the countdown.
4. Scroll down for the photo showcase, full story, letter, and wish section.
5. “Apna Bana Le” is included locally at assets/audio/apna-bana-le.mp3.

Birthday countdown target: 02 October 2026 (IST). After that date it automatically counts toward 02 October 2027.
